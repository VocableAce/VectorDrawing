﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VectorDrawing
{
    public class Vector
    {
        public List<Point> points = new List<Point>();
        int m_sizeX, m_sizeY; //These are only for creating the cube

        public void Create(int startingPointX, int startingPointY, int sizeX, int sizeY)
        {
            m_sizeX = sizeX;
            m_sizeY = sizeY;

            points.Add(new Point(startingPointX, startingPointY)); //A Line Start
            points.Add(new Point(startingPointX + sizeX, startingPointY)); //A Line End

            points.Add(new Point(startingPointX + sizeX, startingPointY)); //B Line Start
            points.Add(new Point(startingPointX + sizeX, startingPointY + sizeY)); //B Line End

            points.Add(new Point(startingPointX, startingPointY)); //A + B Line Start
            points.Add(new Point(startingPointX + sizeX, startingPointY + sizeY)); //A + B Line End
        }

        public void Draw(Color outline, Brush color, float thickness, Graphics g)
        {
            g.FillRectangle(color, points[0].X, points[0].Y, m_sizeX, m_sizeY); //A Filled Rectangle

            g.DrawLine(new Pen(outline, thickness), points[0], points[1]); //A Line
            g.DrawLine(new Pen(outline, thickness), points[2], points[3]); //B Line
            g.DrawLine(new Pen(outline, thickness), points[4], points[5]); // A + B (C)? Line

            //Uncomment the A + B (C)? (I think it's called C, not sure) Line if you want to see it
        }
    }
}
