﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VectorDrawing
{
    public class RectangleVector
    {
        List<Vector> vectors = new List<Vector>();

        public void Create(int spX, int spY, int sizeX, int sizeY)
        {
            Vector s1 = new Vector();
            s1.Create(spX, spY, sizeX, sizeY);

            Vector s2 = new Vector();
            s2.Create(s1.points[5].X, s1.points[5].Y, -sizeX, -sizeY);

            vectors.Add(s1);
            vectors.Add(s2);
        }

        public void Draw(Color c, Brush b, float t, Graphics g)
        {
            vectors.ForEach(v => v.Draw(c, b, t, g));
        }
    }
}
