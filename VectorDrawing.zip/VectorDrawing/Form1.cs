﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VectorDrawing
{
    public partial class MainForm : Form
    {
        List<Vector> vectors = new List<Vector>(); //I don't see the purpose in me keeping this, but I'll keep it here
        List<RectangleVector> rectangles = new List<RectangleVector>();

        public MainForm()
        {
            InitializeComponent();
        }

        Random r;

        private void Form1_Load(object sender, EventArgs e)
        {
            r = new Random();

            for (int i = 0; i < 43; i++)
            {
                for (int j = 0; j < 22; j++)
                {
                    //Creates a nice 32x32 grid of cubes
                    RectangleVector rv = new RectangleVector();
                    rv.Create(i * 32, j * 32, 32, 32);
                    rectangles.Add(rv);
                }
            }
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            //Draws all rectangles in the List
            rectangles.ForEach(k => k.Draw(Color.Blue, Brushes.Green, 3, e.Graphics));
        }

        private void MainForm_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'a')
            {
                DialogResult box = MessageBox.Show("This program was made just for me to see if I could draw vectors\n(The Outlines you see) and understand how to use them, because I was influenced to research them. It soon turned into me making basic boxes with them, and then this. Of course I made the source available for editing.\nI made this in about, 1 or 2 hours.\n", "About this Program");
            }
        }
    }
}
